<?php

	header("location: ../");

?>