<?php

	header("location: ../../");

?>